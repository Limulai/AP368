#ifndef	_COMMON_H_
#define _COMMON_H_

#include "mydefine.h"
U16  get_table_value(U16 key,const U16* table);

#endif

